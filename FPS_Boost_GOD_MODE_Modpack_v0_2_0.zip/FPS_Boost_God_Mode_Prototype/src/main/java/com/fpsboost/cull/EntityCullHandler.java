package com.fpsboost.cull;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Cancels the client-side draw call of distant living entities. Players and named
 * entities are never skipped. Simulation is untouched (render-only).
 */
@Mod.EventBusSubscriber(modid = EntityCullMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class EntityCullHandler {
    private static int farDrawnThisFrame;

    private EntityCullHandler() {}

    @SubscribeEvent
    public static void onRenderTick(TickEvent.RenderTickEvent event) {
        if (event.phase == TickEvent.Phase.START) farDrawnThisFrame = 0;
    }

    @SubscribeEvent
    public static void onRenderLiving(RenderLivingEvent.Pre<?, ?> event) {
        if (!EntityCullConfig.ENABLED.get()) return;
        LivingEntity entity = event.getEntity();
        if (entity instanceof Player || entity.hasCustomName()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        double distSqr = entity.distanceToSqr(mc.player);
        double near = EntityCullConfig.NEAR_BLOCKS.get();
        if (distSqr <= near * near) return;

        double max = EntityCullConfig.MAX_RENDER_BLOCKS.get();
        if (distSqr > max * max || ++farDrawnThisFrame > EntityCullConfig.MAX_FAR_PER_FRAME.get()) {
            event.setCanceled(true);
        }
    }
}
