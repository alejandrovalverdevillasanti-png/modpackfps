package com.fpsboost.cull;

import net.minecraftforge.common.ForgeConfigSpec;

public final class EntityCullConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.IntValue MAX_RENDER_BLOCKS;
    public static final ForgeConfigSpec.IntValue NEAR_BLOCKS;
    public static final ForgeConfigSpec.IntValue MAX_FAR_PER_FRAME;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("entity_limiter");
        ENABLED = b.comment("Skip RENDERING of far-away living entities. Never affects AI, hitboxes or gameplay.")
                .define("enabled", true);
        MAX_RENDER_BLOCKS = b.comment("Living entities farther than this (blocks) are not drawn.")
                .defineInRange("max_render_blocks", 48, 8, 512);
        NEAR_BLOCKS = b.comment("Entities closer than this are always drawn.")
                .defineInRange("near_blocks", 16, 0, 128);
        MAX_FAR_PER_FRAME = b.comment("Max entities drawn per frame beyond near_blocks; extra ones are skipped that frame.")
                .defineInRange("max_far_per_frame", 64, 1, 2048);
        b.pop();
        SPEC = b.build();
    }
    private EntityCullConfig() {}
}
