package com.fpsboost.cull;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

/** FPS Boost Entity Limiter: render-only distance + per-frame budget for living entities. */
@Mod(EntityCullMod.MODID)
public final class EntityCullMod {
    public static final String MODID = "fpsboost_cull";

    public EntityCullMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, EntityCullConfig.SPEC, "fpsboost-entity-limiter-client.toml");
    }
}
