package com.fpsboost;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

@Mod(FpsBoostMod.MODID)
public final class FpsBoostMod {
    public static final String MODID = "fpsboost";

    public FpsBoostMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, FpsBoostConfig.SPEC);
    }
}
