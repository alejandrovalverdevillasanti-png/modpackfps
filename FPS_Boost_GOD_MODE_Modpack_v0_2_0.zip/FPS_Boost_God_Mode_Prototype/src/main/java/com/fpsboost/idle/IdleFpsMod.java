package com.fpsboost.idle;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

/** FPS Boost Idle Limiter: low FPS cap while the window is unfocused. */
@Mod(IdleFpsMod.MODID)
public final class IdleFpsMod {
    public static final String MODID = "fpsboost_idle";

    public IdleFpsMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, IdleFpsConfig.SPEC, "fpsboost-idle-client.toml");
    }
}
