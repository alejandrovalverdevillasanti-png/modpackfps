package com.fpsboost.idle;

import net.minecraftforge.common.ForgeConfigSpec;

public final class IdleFpsConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.IntValue IDLE_FPS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("idle_limiter");
        ENABLED = b.comment("Cap FPS while the game window is not focused (saves battery, heat and GPU).")
                .define("enabled", true);
        IDLE_FPS = b.defineInRange("idle_fps", 10, 1, 60);
        b.pop();
        SPEC = b.build();
    }
    private IdleFpsConfig() {}
}
