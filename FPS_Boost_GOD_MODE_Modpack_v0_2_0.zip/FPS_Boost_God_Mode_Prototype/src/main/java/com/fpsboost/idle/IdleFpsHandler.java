package com.fpsboost.idle;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/** Changes only the window's runtime frame cap (not options.txt), and restores it on focus. */
@Mod.EventBusSubscriber(modid = IdleFpsMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class IdleFpsHandler {
    private static boolean throttled;
    private static int savedLimit;

    private IdleFpsHandler() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        boolean wantThrottle = IdleFpsConfig.ENABLED.get() && !mc.isWindowActive();
        if (wantThrottle && !throttled) {
            savedLimit = mc.getWindow().getFramerateLimit();
            mc.getWindow().setFramerateLimit(IdleFpsConfig.IDLE_FPS.get());
            throttled = true;
        } else if (!wantThrottle && throttled) {
            mc.getWindow().setFramerateLimit(savedLimit);
            throttled = false;
        }
    }
}
