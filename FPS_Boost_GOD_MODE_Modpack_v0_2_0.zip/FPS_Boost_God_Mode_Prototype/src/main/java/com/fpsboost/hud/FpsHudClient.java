package com.fpsboost.hud;

import com.fpsboost.client.MemoryDiagnostics;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RenderGuiOverlayEvent;
import net.minecraftforge.client.gui.overlay.VanillaGuiOverlay;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = FpsHudMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class FpsHudClient {
    private static final double GIB = 1024.0 * 1024.0 * 1024.0;
    private static Boolean visible; // null until first read of the config

    private FpsHudClient() {}

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (visible == null) visible = FpsHudConfig.SHOW_ON_START.get();
        while (FpsHudKeys.TOGGLE.consumeClick()) {
            visible = !visible;
        }
    }

    @SubscribeEvent
    public static void onRenderOverlay(RenderGuiOverlayEvent.Post event) {
        // Draw once per frame, together with the hotbar.
        if (event.getOverlay() != VanillaGuiOverlay.HOTBAR.type()) return;
        if (visible == null || !visible) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.options.renderDebug) return; // don't overlap the F3 screen

        int fps = mc.getFps();
        StringBuilder sb = new StringBuilder("FPS ").append(fps);
        if (FpsHudConfig.SHOW_MEMORY.get()) {
            sb.append("  RAM ").append(Math.round(MemoryDiagnostics.usedPercent())).append("% (")
              .append(String.format("%.1f/%.1f GB", MemoryDiagnostics.usedBytes() / GIB, MemoryDiagnostics.maxBytes() / GIB))
              .append(')');
        }
        if (FpsHudConfig.SHOW_RENDER_DISTANCE.get()) {
            sb.append("  RD ").append(mc.options.renderDistance().get());
        }
        int color = fps >= 50 ? 0x55FF55 : fps >= 30 ? 0xFFFF55 : 0xFF5555;
        GuiGraphics g = event.getGuiGraphics();
        g.drawString(mc.font, sb.toString(), FpsHudConfig.X.get(), FpsHudConfig.Y.get(), color, true);
    }
}
