package com.fpsboost.hud;

import net.minecraftforge.common.ForgeConfigSpec;

public final class FpsHudConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue SHOW_ON_START;
    public static final ForgeConfigSpec.BooleanValue SHOW_MEMORY;
    public static final ForgeConfigSpec.BooleanValue SHOW_RENDER_DISTANCE;
    public static final ForgeConfigSpec.IntValue X;
    public static final ForgeConfigSpec.IntValue Y;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("hud");
        SHOW_ON_START = b.comment("Show the overlay when the game starts (toggle in-game with the FPS HUD key, default F8).")
                .define("show_on_start", true);
        SHOW_MEMORY = b.define("show_memory", true);
        SHOW_RENDER_DISTANCE = b.define("show_render_distance", true);
        X = b.defineInRange("x", 4, 0, 4000);
        Y = b.defineInRange("y", 4, 0, 4000);
        b.pop();
        SPEC = b.build();
    }
    private FpsHudConfig() {}
}
