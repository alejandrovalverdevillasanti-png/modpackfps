package com.fpsboost.hud;

import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = FpsHudMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.MOD)
public final class FpsHudKeys {
    /** 297 = GLFW_KEY_F8 */
    public static final KeyMapping TOGGLE = new KeyMapping("key.fpsboost_hud.toggle", 297, "key.categories.fpsboost");

    private FpsHudKeys() {}

    @SubscribeEvent
    public static void register(RegisterKeyMappingsEvent event) {
        event.register(TOGGLE);
    }
}
