package com.fpsboost.hud;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

/** FPS Boost HUD: tiny on-screen FPS / memory / render distance readout. */
@Mod(FpsHudMod.MODID)
public final class FpsHudMod {
    public static final String MODID = "fpsboost_hud";

    public FpsHudMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, FpsHudConfig.SPEC, "fpsboost-hud-client.toml");
    }
}
