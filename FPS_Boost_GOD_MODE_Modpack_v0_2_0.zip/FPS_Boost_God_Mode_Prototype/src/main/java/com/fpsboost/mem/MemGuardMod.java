package com.fpsboost.mem;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

/** FPS Boost Memory Guard: frees RAM while a menu is open, never during gameplay. */
@Mod(MemGuardMod.MODID)
public final class MemGuardMod {
    public static final String MODID = "fpsboost_mem";

    public MemGuardMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, MemGuardConfig.SPEC, "fpsboost-memory-client.toml");
    }
}
