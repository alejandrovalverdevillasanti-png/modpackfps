package com.fpsboost.mem;

import com.fpsboost.client.MemoryDiagnostics;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = MemGuardMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class MemGuardHandler {
    private static int ticks;
    private static long lastRunMillis;

    private MemGuardHandler() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (++ticks < 40) return; // check every ~2 seconds
        ticks = 0;
        if (!MemGuardConfig.ENABLED.get()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.screen == null) return; // only while a menu / pause screen is open
        if (MemoryDiagnostics.usedPercent() < MemGuardConfig.THRESHOLD_PERCENT.get()) return;
        long now = System.currentTimeMillis();
        if (now - lastRunMillis < MemGuardConfig.COOLDOWN_SECONDS.get() * 1000L) return;
        lastRunMillis = now;
        System.gc();
    }
}
