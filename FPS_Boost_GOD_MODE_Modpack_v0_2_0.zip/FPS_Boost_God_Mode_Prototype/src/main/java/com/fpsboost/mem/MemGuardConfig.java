package com.fpsboost.mem;

import net.minecraftforge.common.ForgeConfigSpec;

public final class MemGuardConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.IntValue THRESHOLD_PERCENT;
    public static final ForgeConfigSpec.IntValue COOLDOWN_SECONDS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("memory_guard");
        ENABLED = b.comment("Asks the JVM to free memory ONLY while a menu/pause screen is open (so no stutter while playing).")
                .define("enabled", true);
        THRESHOLD_PERCENT = b.comment("Run only when used memory is at or above this % of the max heap.")
                .defineInRange("threshold_percent", 80, 50, 95);
        COOLDOWN_SECONDS = b.comment("Minimum seconds between two cleanups.")
                .defineInRange("cooldown_seconds", 120, 30, 3600);
        b.pop();
        SPEC = b.build();
    }
    private MemGuardConfig() {}
}
