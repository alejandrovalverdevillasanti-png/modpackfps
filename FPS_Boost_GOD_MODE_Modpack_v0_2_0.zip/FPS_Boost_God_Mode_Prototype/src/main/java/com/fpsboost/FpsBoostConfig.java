package com.fpsboost;

import net.minecraftforge.common.ForgeConfigSpec;

/** User-adjustable client performance settings. */
public final class FpsBoostConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.IntValue MIN_RENDER_DISTANCE;
    public static final ForgeConfigSpec.IntValue MAX_RENDER_DISTANCE;
    public static final ForgeConfigSpec.IntValue LOW_FPS_THRESHOLD;
    public static final ForgeConfigSpec.IntValue HIGH_FPS_THRESHOLD;
    public static final ForgeConfigSpec.BooleanValue ADAPT_PARTICLES;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("adaptive_performance");
        ENABLED = b.comment("Enable automatic client-side performance adjustments.")
                .define("enabled", true);
        MIN_RENDER_DISTANCE = b.comment("Lowest render distance the controller may select.")
                .defineInRange("min_render_distance", 2, 2, 16);
        MAX_RENDER_DISTANCE = b.comment("Highest render distance the controller may restore.")
                .defineInRange("max_render_distance", 6, 2, 32);
        LOW_FPS_THRESHOLD = b.defineInRange("low_fps_threshold", 45, 10, 240);
        HIGH_FPS_THRESHOLD = b.defineInRange("high_fps_threshold", 58, 15, 360);
        ADAPT_PARTICLES = b.comment("Reduce particles under sustained low FPS; restore the user's previous setting.")
                .define("adapt_particles", true);
        b.pop();
        SPEC = b.build();
    }
    private FpsBoostConfig() {}
}
