package com.fpsboost.trim;

import net.minecraftforge.common.ForgeConfigSpec;

public final class TrimConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.BooleanValue ENABLED;
    public static final ForgeConfigSpec.BooleanValue DISABLE_CLOUDS;
    public static final ForgeConfigSpec.BooleanValue DISABLE_ENTITY_SHADOWS;
    public static final ForgeConfigSpec.IntValue MAX_BIOME_BLEND;
    public static final ForgeConfigSpec.IntValue MAX_SIMULATION_DISTANCE;
    public static final ForgeConfigSpec.IntValue MAX_ENTITY_DISTANCE_PERCENT;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        b.push("visual_trim");
        ENABLED = b.comment("Keeps costly video options at or below the caps below. It only LOWERS options, never raises them.")
                .define("enabled", true);
        DISABLE_CLOUDS = b.define("disable_clouds", true);
        DISABLE_ENTITY_SHADOWS = b.define("disable_entity_shadows", true);
        MAX_BIOME_BLEND = b.comment("Vanilla range 0-7. 0 = no biome colour blending (cheaper chunk rebuilds).")
                .defineInRange("max_biome_blend", 0, 0, 7);
        MAX_SIMULATION_DISTANCE = b.comment("Vanilla range 5-32. Lower = fewer chunks ticked on the CPU (big win on phones).")
                .defineInRange("max_simulation_distance", 5, 5, 32);
        MAX_ENTITY_DISTANCE_PERCENT = b.comment("Vanilla entity distance slider, 50-500 (%).")
                .defineInRange("max_entity_distance_percent", 50, 50, 500);
        b.pop();
        SPEC = b.build();
    }
    private TrimConfig() {}
}
