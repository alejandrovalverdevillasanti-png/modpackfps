package com.fpsboost.trim;

import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;

/** FPS Boost Visual Trim: caps costly vanilla video options (clouds, shadows, biome blend, simulation distance...). */
@Mod(TrimMod.MODID)
public final class TrimMod {
    public static final String MODID = "fpsboost_trim";

    public TrimMod() {
        ModLoadingContext.get().registerConfig(ModConfig.Type.CLIENT, TrimConfig.SPEC, "fpsboost-trim-client.toml");
    }
}
