package com.fpsboost.trim;

import net.minecraft.client.CloudStatus;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = TrimMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class TrimHandler {
    private static int ticks;

    private TrimHandler() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        if (++ticks < 100) return; // check every ~5 seconds
        ticks = 0;
        if (!TrimConfig.ENABLED.get()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.options == null) return;
        Options o = mc.options;

        if (TrimConfig.DISABLE_CLOUDS.get() && o.cloudStatus().get() != CloudStatus.OFF) {
            o.cloudStatus().set(CloudStatus.OFF);
        }
        if (TrimConfig.DISABLE_ENTITY_SHADOWS.get() && o.entityShadows().get()) {
            o.entityShadows().set(false);
        }
        cap(o.biomeBlendRadius(), TrimConfig.MAX_BIOME_BLEND.get());
        cap(o.simulationDistance(), TrimConfig.MAX_SIMULATION_DISTANCE.get());
        double maxScale = TrimConfig.MAX_ENTITY_DISTANCE_PERCENT.get() / 100.0;
        if (o.entityDistanceScaling().get() > maxScale + 1.0E-6) {
            o.entityDistanceScaling().set(maxScale);
        }
    }

    private static void cap(OptionInstance<Integer> option, int max) {
        if (option.get() > max) option.set(max);
    }
}
