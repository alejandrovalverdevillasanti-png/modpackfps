package com.fpsboost.client;

import com.fpsboost.FpsBoostConfig;
import com.fpsboost.FpsBoostMod;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleStatus;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * Conservative client-only adaptive controller. It changes presentation settings
 * only; it never changes simulation, entity AI, heap size, or invokes System.gc().
 */
@Mod.EventBusSubscriber(modid = FpsBoostMod.MODID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientPerformanceController {
    private static final int SAMPLE_TICKS = 100;
    private static int ticks;
    private static int lowSamples;
    private static int highSamples;
    private static boolean particlesReduced;
    private static ParticleStatus previousParticles;

    private ClientPerformanceController() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (!FpsBoostConfig.ENABLED.get()) {
            restoreParticles(mc);
            resetCounters();
            return;
        }
        if (mc.level == null || mc.player == null || mc.isPaused()) {
            // Never leave a temporary quality reduction behind after leaving a world
            // or opening the pause menu.
            restoreParticles(mc);
            resetCounters();
            return;
        }
        if (++ticks < SAMPLE_TICKS) return;
        ticks = 0;

        int fps = mc.getFps();
        int distance = mc.options.renderDistance().get();
        int minDistance = Math.min(FpsBoostConfig.MIN_RENDER_DISTANCE.get(), FpsBoostConfig.MAX_RENDER_DISTANCE.get());
        int maxDistance = Math.max(FpsBoostConfig.MIN_RENDER_DISTANCE.get(), FpsBoostConfig.MAX_RENDER_DISTANCE.get());
        int lowThreshold = FpsBoostConfig.LOW_FPS_THRESHOLD.get();
        int highThreshold = Math.max(lowThreshold + 5, FpsBoostConfig.HIGH_FPS_THRESHOLD.get());

        if (fps > 0 && fps < lowThreshold) {
            lowSamples++;
            highSamples = 0;
        } else if (fps >= highThreshold) {
            highSamples++;
            lowSamples = 0;
        } else {
            lowSamples = Math.max(0, lowSamples - 1);
            highSamples = Math.max(0, highSamples - 1);
        }

        if (lowSamples >= 2) {
            if (distance > minDistance) mc.options.renderDistance().set(distance - 1);
            if (FpsBoostConfig.ADAPT_PARTICLES.get()) reduceParticles(mc);
            lowSamples = 0;
        } else if (highSamples >= 4) {
            if (distance < maxDistance) mc.options.renderDistance().set(distance + 1);
            restoreParticles(mc);
            highSamples = 0;
        }
    }

    private static void reduceParticles(Minecraft mc) {
        if (!particlesReduced) {
            previousParticles = mc.options.particles().get();
            mc.options.particles().set(ParticleStatus.DECREASED);
            particlesReduced = true;
        }
    }

    private static void restoreParticles(Minecraft mc) {
        if (particlesReduced && previousParticles != null) {
            mc.options.particles().set(previousParticles);
            particlesReduced = false;
            previousParticles = null;
        }
    }

    private static void resetCounters() {
        ticks = 0;
        lowSamples = 0;
        highSamples = 0;
    }
}
