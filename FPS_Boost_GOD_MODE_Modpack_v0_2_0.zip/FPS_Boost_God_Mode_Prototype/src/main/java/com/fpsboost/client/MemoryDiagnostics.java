package com.fpsboost.client;

/** Read-only JVM memory diagnostics. This class intentionally never calls System.gc(). */
public final class MemoryDiagnostics {
    private MemoryDiagnostics() {}
    public static long usedBytes() { Runtime r = Runtime.getRuntime(); return r.totalMemory() - r.freeMemory(); }
    public static long maxBytes() { return Runtime.getRuntime().maxMemory(); }
    public static double usedPercent() { long max = maxBytes(); return max <= 0 ? 0.0 : (usedBytes() * 100.0) / max; }
}
