#!/usr/bin/env python3
"""Build the FPS BOOST - ULTRA PERFORMANCE: GOD MODE modpack.

Resolves every third-party mod through the Modrinth API (latest *release* for
Minecraft 1.20.1 + Forge, plus required dependencies), verifies SHA-512 of each
download, then writes into build/modpack/:
  * <name>-<ver>.mrpack        Modrinth pack (mods are downloaded by the launcher)
  * <name>-<ver>-instance.zip  Self-contained zip: mods/ + config/ (copy into a Forge 1.20.1 instance)
Our own mod JAR (build/libs/fpsboost-godmode-*.jar) is bundled in both.
Standard library only.
"""
import glob, hashlib, json, os, sys, urllib.parse, urllib.request, zipfile

MC, LOADER, FORGE = "1.20.1", "forge", "47.2.0"
NAME = "FPS BOOST - ULTRA PERFORMANCE GOD MODE"
MODS = ["embeddium", "modernfix", "ferritecore", "entityculling", "immediatelyfast", "clumps"]
API = "https://api.modrinth.com/v2"
UA = {"User-Agent": "fpsboost-godmode-modpack/0.2.0 (github actions build)"}
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "build", "modpack")


def http(url):
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=60) as r:
        return r.read()


def api_get(path, **params):
    q = urllib.parse.urlencode({k: json.dumps(v) if isinstance(v, list) else v for k, v in params.items()})
    return json.loads(http(f"{API}{path}?{q}"))


def latest(project):
    vers = api_get(f"/project/{project}/version", loaders=[LOADER], game_versions=[MC])
    rel = [v for v in vers if v["version_type"] == "release"] or vers
    if not rel:
        raise SystemExit(f"No {MC}/{LOADER} version found for '{project}'")
    return rel[0]  # API returns newest first


def resolve(slugs):
    chosen, queue = {}, list(slugs)
    while queue:
        proj = queue.pop(0)
        v = latest(proj)
        if v["project_id"] in chosen:
            continue
        chosen[v["project_id"]] = v
        print(f"  {proj}: {v['name']} ({v['version_number']})")
        queue += [d["project_id"] for d in v["dependencies"]
                  if d["dependency_type"] == "required" and d.get("project_id")
                  and d["project_id"] not in chosen]
    return list(chosen.values())


def main():
    version = os.environ.get("PACK_VERSION", "0.2.0")
    jars = sorted(glob.glob(os.path.join(ROOT, "build", "libs", "fpsboost-godmode-*.jar")))
    if not jars:
        sys.exit("Own mod JAR missing: run './gradlew build' first.")
    own = jars[-1]
    os.makedirs(OUT, exist_ok=True)

    print("Resolving mods on Modrinth...")
    files, downloaded = [], {}
    for v in resolve(MODS):
        f = next((x for x in v["files"] if x.get("primary")), v["files"][0])
        data = http(f["url"])
        if hashlib.sha512(data).hexdigest() != f["hashes"]["sha512"]:
            sys.exit(f"Hash mismatch for {f['filename']}")
        downloaded[f["filename"]] = data
        files.append({
            "path": f"mods/{f['filename']}",
            "hashes": {"sha1": f["hashes"]["sha1"], "sha512": f["hashes"]["sha512"]},
            "env": {"client": "required", "server": "unsupported"},
            "downloads": [f["url"]],
            "fileSize": len(data),
        })

    overrides = []  # (archive path inside overrides, local path)
    cfg_dir = os.path.join(ROOT, "overrides")
    for dp, _, fn in os.walk(cfg_dir):
        for n in fn:
            p = os.path.join(dp, n)
            overrides.append((os.path.relpath(p, cfg_dir).replace(os.sep, "/"), p))
    overrides.append(("mods/" + os.path.basename(own), own))

    index = {"formatVersion": 1, "game": "minecraft", "versionId": version, "name": NAME,
             "summary": "Client-side performance pack for Minecraft 1.20.1 Forge",
             "files": files, "dependencies": {"minecraft": MC, "forge": FORGE}}
    base = f"FPS_Boost_GOD_MODE-{version}"
    with zipfile.ZipFile(os.path.join(OUT, base + ".mrpack"), "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("modrinth.index.json", json.dumps(index, indent=2))
        for arc, p in overrides:
            z.write(p, "overrides/" + arc)
    with zipfile.ZipFile(os.path.join(OUT, base + "-instance.zip"), "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in downloaded.items():
            z.writestr("mods/" + name, data)
        for arc, p in overrides:
            z.write(p, arc)
    print("Done:", *sorted(os.listdir(OUT)), sep="\n  ")


if __name__ == "__main__":
    main()
