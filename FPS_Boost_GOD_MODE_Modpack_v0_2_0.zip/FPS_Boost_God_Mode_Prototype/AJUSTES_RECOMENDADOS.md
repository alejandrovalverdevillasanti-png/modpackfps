# Ajustes recomendados (móvil, Forge 1.20.1)

## Lo que ya hacen los mods propios (valores por defecto)
| Mod | Valores |
|---|---|
| fpsboost | render distance entre 2 y 6; baja si hay menos de 45 FPS |
| fpsboost_cull | no dibuja seres vivos a más de 32 bloques; máx. 32 lejanos por frame |
| fpsboost_idle | 10 FPS con la ventana sin foco |
| fpsboost_trim | nubes y sombras de entidades OFF; biome blend 0; simulación 5; entidades 50 % (solo BAJA, nunca sube) |
| fpsboost_mem | libera RAM solo con un menú abierto y >= 80 % de uso (cada 120 s como mucho) |
| fpsboost_hud | F8 muestra/oculta FPS, RAM y chunks |

Se editan en `config/fpsboost-*.toml` con el juego cerrado.

## Opciones de vídeo del juego (a mano)
Gráficos: Rápido · Partículas: Mínimas · Mipmaps: 0 · Iluminación suave: apagada o mínima · V-Sync: apagado.

## Distant Horizons (menú del mod)
Thread Preset: Minimal Impact · Quality Preset: el más bajo · distancia de LOD: empezar baja y subir poco a poco.
No hay config de Distant Horizons incluida: se ajusta en su menú.

## Zalith / móvil
Probar todos los renderizadores y quedarse con el mejor · RAM 2-3 GB · resolución 70-80 % · modo rendimiento del móvil · cerrar apps en segundo plano.
