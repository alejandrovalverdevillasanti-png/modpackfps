# FPS BOOST - ULTRA PERFORMANCE: GOD MODE 0.2.0 (modpack)

Target: Minecraft Java 1.20.1 / Forge 47.2.0 / Java 17.

## Implemented in source
- Forge mod entry point and client config registration.
- Client-only adaptive controller sampling FPS every 5 seconds.
- After two sustained low-FPS samples, reduce render distance by one (configurable floor) and optionally reduce particles.
- After four sustained high-FPS samples, restore render distance gradually (configurable ceiling) and restore the particle setting that was active before the mod changed it.
- User-configurable thresholds and enable switch.
- Read-only JVM memory diagnostics; no forced garbage collection.
- CurseForge-style manifest and modpack integration notes.

## Status of phases 1–6
1. Project structure: prepared.
2. Custom mod source: initial adaptive controller implemented.
3. Optimization systems: adaptive render distance, particle fallback and read-only memory diagnostics implemented; no custom GPU/CPU/chunk engine is claimed.
4. Integration: manifest and integration guide prepared; third-party mods remain optional and must be added/tested separately.
5. JAR compilation: not completed. Gradle is not installed in the build environment, so a valid compiled JAR cannot be supplied yet.
6. Zalith package validation: not completed. Must be tested on the target launcher/device after building.

## Mods propios incluidos (todos client-side, un solo JAR)
| Mod (modId) | Qué hace | Config generada |
|---|---|---|
| `fpsboost` | Controlador adaptativo: baja/sube render distance y partículas según FPS sostenidos. | `fpsboost-client.toml` |
| `fpsboost_hud` | HUD con FPS (verde/amarillo/rojo), RAM usada y render distance. Tecla **F8** para mostrar/ocultar. No se dibuja con F3. | `fpsboost-hud-client.toml` |
| `fpsboost_cull` | Limitador de entidades: no *dibuja* seres vivos lejanos (>48 bloques) ni más de 64 lejanos por frame. Nunca afecta a jugadores, mobs con nombre, IA ni hitboxes. | `fpsboost-entity-limiter-client.toml` |
| `fpsboost_idle` | Limita a 10 FPS cuando la ventana no tiene foco y restaura el límite al volver (no toca options.txt). | `fpsboost-idle-client.toml` |

## Cómo obtener el modpack terminado
El modpack contiene: tu mod `fpsboost` (compilado) + Embeddium, ModernFix, FerriteCore, Entity Culling, ImmediatelyFast y Clumps
(última versión *release* para 1.20.1 Forge, con dependencias requeridas, resueltas por la API de Modrinth y con hashes verificados).

**Sin instalar nada (sirve desde el móvil):**
1. Sube esta carpeta a un repositorio nuevo de GitHub.
2. Pestaña *Actions* -> "Build modpack" (se ejecuta sola al hacer push).
3. Descarga el artefacto `FPS_Boost_GOD_MODE_modpack`. Contiene:
   - `FPS_Boost_GOD_MODE-0.2.0.mrpack`: importable en Modrinth App, Prism, ATLauncher y launchers que soporten .mrpack.
   - `FPS_Boost_GOD_MODE-0.2.0-instance.zip`: carpetas `mods/` y `config/` listas para copiar a una instancia Forge 1.20.1-47.2.0 (p. ej. Zalith).

**En un PC con JDK 17 y Python 3:** `./gradlew build && python3 tools/build_modpack.py` (salida en `build/modpack/`).

Para cambiar los mods incluidos edita la lista `MODS` en `tools/build_modpack.py`.
`manifest.json` (formato CurseForge) queda solo como referencia; no se usa en el build.

## Estado de verificación
- Los 4 mods propios se comprobaron con `javac --release 17` contra stubs de la API (sintaxis y tipos OK).
- `tools/build_modpack.py` se probó offline con una API simulada (estructura de .mrpack y zip correctas); no se ejecutó contra Modrinth real.
- NO se pudo ejecutar un build real de ForgeGradle ni lanzar Minecraft en el entorno donde se preparó (sin acceso al Maven de Forge). Por eso no se incluye ningún .jar precompilado: uno compilado a mano fallaría en runtime por los nombres SRG de Forge.
- Cambios en 0.1.2/0.2.0: wrapper Gradle añadido; se quitó `FAIL_ON_PROJECT_REPOS` (incompatible con ForgeGradle 6); versión inyectada en mods.toml desde gradle.properties; `displayTest` para poder entrar a servidores sin el mod; dependencias marcadas como CLIENT; workflow de CI.

## Test protocol
1. Build and launch with only this mod in a disposable Forge 1.20.1 instance.
2. Confirm config generation and that manual settings are restored correctly.
3. Test low/high FPS transitions in the same reproducible world.
4. Add optional performance mods one at a time; inspect `logs/latest.log` after each launch.
5. Copy the tested JAR and compatible mods into the Zalith Forge profile.

No fixed FPS result is guaranteed. Performance depends on device thermals, drivers, world, mod mix and settings. The mod does not alter world simulation or chunk generation speed.
