# FPS BOOST – ULTRA PERFORMANCE: GOD MODE

Target profile: Minecraft Java 1.20.1, Forge 47.2.0, Java 17, with a conservative Android/Zalith profile.

## Included custom components
- `fpsboost`: adaptive client settings controller and client config.
- `fpsboost_hud`: FPS / RAM / render-distance overlay (key F8).
- `fpsboost_cull`: render-only limiter for distant living entities.
- `fpsboost_idle`: low FPS cap while the window is unfocused.

## Optional third-party performance components to evaluate
Add these manually from their official project pages and use only builds explicitly marked for Forge 1.20.1:
- Embeddium: renderer optimization (use instead of, not alongside, another incompatible renderer replacement).
- ModernFix: startup, memory and general optimization.
- FerriteCore: memory usage optimization.
- Entity Culling: skip rendering hidden entities/block entities.
- ImmediatelyFast: optimize selected immediate rendering paths.
- Clumps: combine XP orbs to reduce entity overhead.

Do not assume every combination is compatible. Add one component at a time, launch, inspect `latest.log`, then benchmark the same world and settings. Do not install OptiFine alongside Embeddium unless a specific compatibility setup documents it.

## What this mod does not claim
It does not accelerate world generation, force faster chunk generation, change server simulation, overclock hardware, or guarantee a fixed FPS. The controller changes client render distance gradually and can lower particles after sustained low FPS. It restores the particle setting it found before making its change.

## Suggested Android starting point
- Render distance: 5–8 chunks.
- Simulation distance: 4–5 chunks.
- Graphics: Fast; clouds off; entity distance 50–75%.
- Allocate a moderate heap rather than all physical RAM; Android needs memory too.
- Disable shaders and high-resolution resource packs when prioritizing FPS.
